# SynthModem context pack

This tarball is supplementary reference material for a Claude session
picking up SynthModem work. It contains two things:

1. **`transcripts/`** — every prior development session's transcript,
   plus `journal.txt` which summarizes each. Reference these when
   Handoff.md mentions "see transcript YYYY-MM-DD" or when you need
   the full history behind a specific decision.

2. **`dmodem-reference/`** — pruned snapshot of the synexo/D-Modem
   project at tag `pjsip2.15`. This is the upstream reference
   implementation we modeled after. Contents:
   - `d-modem.c` — PJSIP media port bridging PJSIP ↔ slmodemd.
     The authoritative example of how to drive slmodemd's audio
     socketpair. Read `dmodem_put_frame` and `on_call_media_state`
     when designing anything touching the audio path.
   - `slmodemd/` — D-Modem's slmodemd source. Byte-identical to the
     copy vendored at `vm/slmodemd/` in our repo. Handy for `diff`
     if we ever wonder if we patched something unintentionally.
   - `Makefile`, `README.md`, `COPYING` — D-Modem's top-level build
     and docs.

## What's been pruned

To keep the tarball manageable:
- `pjproject-2.15.1/` — the bundled PJSIP source (~200 MB). D-Modem
  ships it but we don't need it unless pursuing the in-VM PJSIP
  plan (see `PJSIP.md` in the main repo).
- `dsplibs.o` and `.bin` binary blobs — reverse-engineered SoftK56
  firmware. Not needed for code-level understanding.
- `doc/` — D-Modem's RE scratch work (disassembly chunks, state
  graphs). Not useful for our purposes.

## Unpacking

```bash
tar -xzf synthmodem-context.tar.gz -C /some/working/dir
```

Then in the Claude sandbox, reference paths like:
- `/mnt/user-data/uploads/synthmodem-context.tar.gz :: dmodem-reference/d-modem.c`
- `/mnt/user-data/uploads/synthmodem-context.tar.gz :: transcripts/2026-04-22-21-01-27-synthmodem-clock-pump-post-mortem.txt`

## Transcripts index

The `transcripts/journal.txt` file has short summaries of each. The
most recent session transcripts are typically the most relevant —
read the latest 2-3 first before diving into older ones.

As of this pack:
- Most recent working state: Clock Pump v2 deployed, 100% handshake,
  BBS browsing confirmed. See Handoff.md §3 and §7 in the main repo.
